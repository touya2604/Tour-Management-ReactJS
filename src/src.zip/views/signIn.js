import React from "react";
import SignInForm from "../components/signinForm";

class SignIn extends React.Component {
  render() {
    return (
      <>
        {" "}
        <SignInForm></SignInForm>
      </>
    );
  }
}

export default SignIn;
