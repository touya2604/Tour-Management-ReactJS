const UserTest = [
  {
    id: "0",
    email: "Tanh",
    fullName: "Tanh",
    phone: "095",
    status: "Good",
    role: "admin",
  },
];

export default UserTest;
