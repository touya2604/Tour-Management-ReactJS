const newsTest = [
  {
    id: 1,
    title: "KHÁM PHÁ ALISHAN ĐÀI LOAN – HÀNH TRÌNH CHẠM ĐẾN NÚI RỪNG THƠ MỘNG",
    description: "Nếu du khách đang tìm kiếm một chốn bình yên...",
    image: "https://example.com/alishan.jpg",
  },
  {
    id: 2,
    title:
      "LÀNG CỔ HÀN QUỐC – NƠI HƠI THỞ LỊCH SỬ GIAO THOA VỚI NHỊP SỐNG HIỆN ĐẠI",
    description: "Hãy để những làng cổ Hàn Quốc đưa du khách vào...",
    image: "https://example.com/korea.jpg",
  },
];

export default newsTest;
