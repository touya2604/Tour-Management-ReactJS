const vouchers = [
  {
    id: 1,
    percent: 30,
    minimum: 5,
    timeStart: "2022-04-20",
    timeEnd: "2022-04-20",
  },
  {
    id: 2,
    percent: 30,
    minimum: 5,
    timeStart: "2022-04-20",
    timeEnd: "2022-04-20",
  },
  {
    id: 3,
    percent: 30,
    minimum: 5,
    timeStart: "2022-04-20",
    timeEnd: "2022-04-20",
  },
  {
    id: 4,
    percent: 30,
    minimum: 5,
    timeStart: "2022-04-20",
    timeEnd: "2022-04-20",
  },
  {
    id: 5,
    percent: 30,
    minimum: 5,
    timeStart: "2022-04-20",
    timeEnd: "2022-04-20",
  },
  {
    id: 6,
    percent: 30,
    minimum: 5,
    timeStart: "2022-04-20",
    timeEnd: "2022-04-20",
  },
];

export default vouchers;
