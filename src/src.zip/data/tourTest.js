const tours = [
  {
    id: 1,
    name: "HÀ NỘI – NINH BÌNH – HẠ LONG",
    image: "https://via.placeholder.com/300x200",
    price: "3.190.000",
    capacity: 30,
  },
  {
    id: 2,
    name: "Du Lịch Đà Nẵng - Hội An - Bà Nà - Cầu Vàng",
    image: "https://via.placeholder.com/300x200",
    price: "6.949.000",
    capacity: 40,
  },
  {
    id: 3,
    name: "Du lịch Hà Nội - Nhà Trang - Hòn Tằm",
    image: "https://via.placeholder.com/300x200",
    price: "5.190.000",
    capacity: 25,
  },
  {
    id: 4,
    name: "Du Lịch Liên Tuyến Nha Trang - Đà Lạt",
    image: "https://via.placeholder.com/300x200",
    price: "4.990.000",
    capacity: 10,
  },
  {
    id: 5,
    name: "Du Lịch Nha Trang - Du Thuyền Emperor 5*",
    image: "https://via.placeholder.com/300x200",
    price: "10.279.000",
    capacity: 20,
  },
  {
    id: 6,
    name: "ĐÀ NẴNG – HỘI AN – BÀ NÀ – HUẾ",
    image: "https://via.placeholder.com/300x200",
    price: "3.990.000",
    capacity: 30,
  },
];

export default tours;
