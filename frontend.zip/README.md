# Giao diện Website đặt tour du lịch
- Sử dụng ReactJS, Bootstrap, HTML, SCSS
- Để chạy thì cần cài đặt môi trường nodejs sau đó chạy "npm i" để cài các thư viện cần thiết
- Sau đó chạy "npm start"
